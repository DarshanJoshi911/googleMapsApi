package com.darshan.googlemapsapi;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    //variables
    EditText ed1,ed2;
    Button mapbtn,findbtn,googleMaps;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Getting all the elements in to the variables
        ed1 = findViewById(R.id.lat);
        ed2 = findViewById(R.id.lon);
        findbtn = findViewById(R.id.find);
        googleMaps = findViewById(R.id.map);

        // Google maps onclick event to open with lat & lon
        googleMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //converting the values to double from the edit text
                double lat = Double.parseDouble(ed1.getText().toString());
                double lon = Double.parseDouble(ed2.getText().toString());

                // Intent to pass to Google Maps App to find the best possible marker point
                String uri = String.format(Locale.ENGLISH, "http://maps.google.com/maps?q=loc:%f,%f", lat, lon);
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                startActivity(intent);
            }
        });

        // Internal Google Maps API provided function
        findbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Taking the values of lot & lon in string
                String lat = ed1.getText().toString();
                String lon = ed2.getText().toString();

                // Intent to pass the values to other activity
                Intent newIntent = new Intent(MainActivity.this, latLongMaps.class);
                    newIntent.putExtra("latitude", lat);
                    newIntent.putExtra("longitude", lon);
                    MainActivity.this.startActivity(newIntent);
            }
        });

        // Find the location of CEGEP on the map activity
        mapbtn = findViewById(R.id.button);
        mapbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent to pass to the google maps activity to show the place of CEGEP
                Intent myIntent = new Intent(MainActivity.this, MapsActivity.class);
                // starting the activity
                MainActivity.this.startActivity(myIntent);
            }
        });
    }
}